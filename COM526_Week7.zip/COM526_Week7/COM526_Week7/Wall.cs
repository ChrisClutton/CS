﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COM526_Week7
{
    public class Wall
    {
        public double Length { get; set; }
        public double Height { get; set; }
    }
}
